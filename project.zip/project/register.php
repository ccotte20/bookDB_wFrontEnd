<?php

include 'config.php';

if(isset($_POST['submit'])){

   $FirstName = mysqli_real_escape_string($conn, $_POST['FirstName']);
   $LastName = mysqli_real_escape_string($conn, $_POST['LastName']);
   $Email = mysqli_real_escape_string($conn, $_POST['Email']);
   $Password = mysqli_real_escape_string($conn, md5($_POST['Password']));
   $cpass = mysqli_real_escape_string($conn, md5($_POST['cpassword']));
   

   $select_users = mysqli_query($conn, "SELECT * FROM `Customers` WHERE Email = '$Email' AND Password = '$Password'") or die('query failed');

   if(mysqli_num_rows($select_users) > 0){
      $message[] = 'User Exists, Please Login!';
   }else{
      if($Password != $cpass){
         $message[] = 'Passwords do not match!!';
      }else{
         mysqli_query($conn, "INSERT INTO `Customers`(FirstName, LastName, Email, Password) VALUES('$FirstName', '$LastName', '$Email', '$cpass')") or die('query failed');
         $message[] = 'Registered successfully!';
         header('location:login.php');
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Registration Form</title>

   <!-- Font  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- CSS -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<div class="form-container">

   <form action="" method="post">
      <h3>Registration Form</h3>
      <input type="text" name="FirstName" placeholder="First Name" required class="box">
      <input type="text" name="LastName" placeholder="Last Name" required class="box">
      <input type="email" name="Email" placeholder="Email Address" required class="box">
      <input type="password" name="Password" placeholder="Password" required class="box">
      <input type="password" name="cpassword" placeholder="Confirm Password" required class="box">
      <input type="submit" name="submit" value="Register" class="btn">
      <p>Already have an account? <a href="login.php">Login</a></p>
   </form>

</div>

</body>
</html>
