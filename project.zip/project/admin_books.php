<?php

include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};

if(isset($_POST['add_book'])){

   $ISBN = mysqli_real_escape_string($conn, $_POST['ISBN']);
   $Title = mysqli_real_escape_string($conn, $_POST['Title']);
   $PublicationDate = mysqli_real_escape_string($conn, $_POST['PublicationDate']);
   $Price = mysqli_real_escape_string($conn, $_POST['Price']);
   $Image = mysqli_real_escape_string($conn, $_POST['Image']);

   $select_author_name = mysqli_query($conn, "SELECT ISBN, Title, Price, PublicationDate FROM `Books` WHERE ISBN= '$ISBN' AND Title= '$Title' AND Price= '$Price' AND PublicationDate= '$PublicationDate'") or die('query failed');

   if(mysqli_num_rows($select_author_name) > 0){
      $message[] = 'Books Already Exists!';
   }else{
      $add_author_query = mysqli_query($conn, "INSERT INTO `Books`(ISBN, Title, PublicationDate, Price, Image) VALUES('$ISBN', '$Title', '$PublicationDate', '$Price', '$Image')") or die('query failed');

      if($add_author_query){
         $message[] = 'Books added successfully!';
      }else{
         $message[] = 'Books failed to be added!';
      }
   }
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM `Books` WHERE ISBN = '$delete_id'") or die('query failed');
   header('location:admin_books.php');
}

if(isset($_POST['update_book'])){

   $update_isbn = $_POST['update_isbn'];
   $update_title = $_POST['update_title'];
   $update_publicationdate = $_POST['update_publicationdate'];
   $update_price = $_POST['update_price'];
   $update_image = $_POST['update_image'];

   mysqli_query($conn, "UPDATE `Books` SET ISBN = '$update_isbn' , Title= '$update_title' , PublicationDate = '$update_publicationdate' , Price = '$update_price', Image='$update_image' WHERE ISBN = '$update_isbn'" ) or die('query failed');

   header('location:admin_books.php');

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Books</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php include 'admin_header.php'; ?>

<!-- product CRUD section starts  -->

<section class="add-products">


   <form action="" method="post" enctype="multipart/form-data">
      <input type="text" name="ISBN" class="box" placeholder="ISBN" required>
      <input type="text" name="Title" class="box" placeholder="Book Title" required>
      <input type="date" name="PublicationDate" class="box"  required>
      <input type="number" name="Price" class="box" placeholder="Price" required>
      <input type="text" name="Image" class="box" placeholder="Image Link" required>
      <input type="submit" value="Add" name="add_book" class="btn">
   </form>

</section>

<!-- product CRUD section ends -->

<!-- show products  -->

<section class="show-products">

   <div class="box-container">

      <?php
         $select_books = mysqli_query($conn, "SELECT * FROM `Books`") or die('query failed');
         if(mysqli_num_rows($select_books) > 0){
            while($fetch_authors = mysqli_fetch_assoc($select_books)){
      ?>
      <div class="box">
         <div class="name"><?php echo $fetch_authors['ISBN']; ?></div>
         <div class="name"><?php echo $fetch_authors['Title']; ?></div>
         <div class="name"><?php echo $fetch_authors['Price']; ?></div>
         <div class="name"><?php echo $fetch_authors['PublicationDate']; ?></div>
         <div class="name"><img src="<?php echo $fetch_authors['Image']; ?>" width="200" height="100"></div>
         <a href="admin_books.php?update=<?php echo $fetch_authors['ISBN']; ?>" class="option-btn">Edit</a>
         <a href="admin_books.php?delete=<?php echo $fetch_authors['ISBN']; ?>" class="delete-btn" onclick="return confirm('Delete this category?');">Delete</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty"> There are no books!</p>';
      }
      ?>
   </div>

</section>

<section class="edit-product-form">

   <?php
      if(isset($_GET['update'])){
         $update_id = $_GET['update'];
         $update_query = mysqli_query($conn, "SELECT * FROM `Books` WHERE ISBN = '$update_id'") or die('query failed');
         if(mysqli_num_rows($update_query) > 0){
            while($fetch_update = mysqli_fetch_assoc($update_query)){
   ?>
   <form action="" method="post" enctype="multipart/form-data">
      <input type="text" name="update_isbn" value="<?php echo $fetch_update['ISBN']; ?>"  class="box" required placeholder="ISBN">
      <input type="text" name="update_title" value="<?php echo $fetch_update['Title']; ?>" class="box" required placeholder="Book Title">
      <input type="date" name="update_publicationdate" value="<?php echo $fetch_update['PublicationDate']; ?>" class="box" required>
      <input type="text" name="update_image" value="<?php echo $fetch_update['Image']; ?>" class="box" placeholder="Image Link" required>
      <input type="number" name="update_price"  type="number" min="0.00" value="<?php echo $fetch_update['Price']; ?>" class="box" placeholder="Price" required>
      <input type="submit" value="update" name="update_book" class="btn">
      <input type="reset" value="cancel" id="close-update" class="option-btn">
   </form>
   <?php
         }
      }
      }else{
         echo '<script>document.querySelector(".edit-product-form").style.display = "none";</script>';
      }
   ?>

</section>







<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>
