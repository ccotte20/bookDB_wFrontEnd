<?php

$conn = mysqli_connect('localhost','root','password','dbname') or die('connection failed');

?>
