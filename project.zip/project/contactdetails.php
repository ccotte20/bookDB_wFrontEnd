<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

if(isset($_POST['add_contact'])){

   $FirstName = mysqli_real_escape_string($conn, $_POST['FirstName']);
   $LastName = mysqli_real_escape_string($conn, $_POST['LastName']);
   $Phone = $_POST['Phone'];
   $Street = mysqli_real_escape_string($conn, $_POST['Street']);
   $City = mysqli_real_escape_string($conn, $_POST['City']);
   $State = mysqli_real_escape_string($conn, $_POST['State']);
   $ZIP = mysqli_real_escape_string($conn, $_POST['ZIP']);
  
   

   $select_address = mysqli_query($conn, "SELECT FirstName, LastName, Phone, Street, City, ZIP , State, CustomerID FROM `CustomerContactDetails` WHERE FirstName= '$FirstName' AND LastName= '$LastName' AND Phone= '$Phone' AND Street= '$Street' AND City= '$City' AND ZIP= '$ZIP' AND State= 'State' AND CustomerID='$user_id'") or die('query failed');

   if(mysqli_num_rows($select_address) > 0){
      $message[] = 'CustomerContactDetails Already Exists!';
   }else{
      $add_author_query = mysqli_query($conn, "INSERT INTO `CustomerContactDetails` (FirstName, LastName, Phone, Street, City, ZIP, State, CustomerID) VALUES('$FirstName', '$LastName', '$Phone', '$Street', '$City', '$ZIP', '$State', '$user_id')") or die('query failed');

      if($add_author_query){
         $message[] = 'Contact Details added successfully!';
      }else{
         $message[] = 'Contact Details failed to be added!';
      }
   }
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM `CustomerContactDetails` WHERE CustomerContactID = '$delete_id'") or die('query failed');
   header('location:contactdetails.php');
}

if(isset($_POST['update_contact'])){

    $Update_ContactID = $_POST['Update_ContactID'];
    $Update_FirstName = $_POST['Update_FirstName'];
    $Update_LastName =  $_POST['Update_LastName'];
    $Update_Phone = $_POST['Update_Phone'];
    $Update_Street =  $_POST['Update_Street'];
    $Update_City = $_POST['Update_City'];
    $Update_State = $_POST['Update_State'];
    $Update_ZIP =  $_POST['Update_ZIP'];
 

   mysqli_query($conn, "UPDATE `CustomerContactDetails` SET FirstName='$Update_FirstName', LastName='$Update_LastName', Phone='$Update_Phone', Street='$Update_Street', City='$Update_City', ZIP='$Update_ZIP' , State='$Update_State' WHERE CustomerContactID = '$Update_ContactID'" ) or die('query failed');

   header('location:contactdetails.php');

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Contact Details</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<!-- product CRUD section starts  -->

<section class="add-products">

   <h1 class="title">Add Contact Details</h1>

   <form action="" method="post" enctype="multipart/form-data">
      <input type="text" name="FirstName" class="box" placeholder="First Name" required>
      <input type="text" name="LastName" class="box" placeholder="Last Name" required>
      <input type="number" name="Phone" class="box" placeholder="Phone Number" required>
      <input type="text" name="Street" class="box" placeholder="Street" required>
      <input type="text" name="City" class="box" placeholder="City" required>
      <input type="text" name="State" class="box" placeholder="State" required>
      <input type="number" name="ZIP" class="box" placeholder="ZIP Code" required>
      <input type="submit" value="Add" name="add_contact" class="btn">
   </form>

</section>

<!-- product CRUD section ends -->

<!-- show products  -->

<section class="show-products">

   <div class="box-container">

      <?php
         $select_categories = mysqli_query($conn, "SELECT * FROM `CustomerContactDetails` Where CustomerID ='$user_id'") or die('query failed');
         if(mysqli_num_rows($select_categories) > 0){
            while($fetch_contacts = mysqli_fetch_assoc($select_categories)){
      ?>
      <div class="box">
         <div class="name"><?php echo $fetch_contacts['FirstName']; ?></div>
         <div class="name"><?php echo $fetch_contacts['LastName']; ?></div>
         <div class="name"><?php echo $fetch_contacts['Phone']; ?></div>
         <div class="name"><?php echo $fetch_contacts['Street']; ?></div>
         <div class="name"><?php echo $fetch_contacts['City']; ?></div>
         <div class="name"><?php echo $fetch_contacts['State']; ?></div>
         <div class="name"><?php echo $fetch_contacts['ZIP']; ?></div>
         <a href="contactdetails.php?update=<?php echo $fetch_contacts['CustomerContactID']; ?>" class="option-btn">Edit</a>
         <a href="contactdetails.php?delete=<?php echo $fetch_contacts['CustomerContactID']; ?>" class="delete-btn" onclick="return confirm('Delete this contact?');">Delete</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty"> There are no contact details!</p>';
      }
      ?>
   </div>

</section>

<section class="edit-product-form">

   <?php
      if(isset($_GET['update'])){
         $update_id = $_GET['update'];
         $update_query = mysqli_query($conn, "SELECT * FROM `CustomerContactDetails` WHERE CustomerContactID = '$update_id'") or die('query failed');
         if(mysqli_num_rows($update_query) > 0){
            while($fetch_update = mysqli_fetch_assoc($update_query)){
   ?>
   <form action="" method="post" enctype="multipart/form-data">
      <input type="hidden" name="Update_ContactID" value="<?php echo $fetch_update['CustomerContactID']; ?>">
      <input type="text" name="Update_FirstName" value="<?php echo $fetch_update['FirstName']; ?>" class="box" required placeholder="First Name">
      <input type="text" name="Update_LastName" value="<?php echo $fetch_update['LastName']; ?>" class="box" required placeholder="Last Name">
      <input type="number" name="Update_Phone" value="<?php echo $fetch_update['Phone']; ?>" class="box" required placeholder="Phone">
      <input type="text" name="Update_Street" value="<?php echo $fetch_update['Street']; ?>" class="box" required placeholder="Street Address">
      <input type="text" name="Update_City" value="<?php echo $fetch_update['City']; ?>" class="box" required placeholder="City">
      <input type="text" name="Update_State" value="<?php echo $fetch_update['State']; ?>" class="box" required placeholder="State">
      <input type="number" name="Update_ZIP" value="<?php echo $fetch_update['ZIP']; ?>" class="box" required placeholder="ZIP Code">
      <input type="submit" value="update" name="update_contact" class="btn">
      <input type="reset" value="cancel" id="close-update" class="option-btn">
   </form>
   <?php
         }
      }
      }else{
         echo '<script>document.querySelector(".edit-product-form").style.display = "none";</script>';
      }
   ?>

</section>







<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>
