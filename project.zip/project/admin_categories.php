<?php

include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};

if(isset($_POST['add_category'])){

   $CategoryName = mysqli_real_escape_string($conn, $_POST['CategoryName']);

   $select_category_name = mysqli_query($conn, "SELECT CategoryName FROM `BookCategory` WHERE CategoryName = '$CategoryName'") or die('query failed');

   if(mysqli_num_rows($select_category_name) > 0){
      $message[] = 'Category Already Exists!';
   }else{
      $add_category_query = mysqli_query($conn, "INSERT INTO `BookCategory`(CategoryName) VALUES('$CategoryName')") or die('query failed');

      if($add_category_query){
         $message[] = 'Category added successfully!';
      }else{
         $message[] = 'Category failed to be added!';
      }
   }
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM `BookCategory` WHERE CategoryCode = '$delete_id'") or die('query failed');
   header('location:admin_categories.php');
}

if(isset($_POST['update_category'])){

   $update_categorycode = $_POST['update_categorycode'];
   $update_categoryname = $_POST['update_categoryname'];

   mysqli_query($conn, "UPDATE `BookCategory` SET CategoryName = '$update_categoryname' WHERE CategoryCode = '$update_categorycode'" ) or die('query failed');

   header('location:admin_categories.php');

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Categories</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php include 'admin_header.php'; ?>

<!-- product CRUD section starts  -->

<section class="add-products">


   <form action="" method="post" enctype="multipart/form-data">
      <input type="text" name="CategoryName" class="box" placeholder="Category Name" required>
      <input type="submit" value="Add" name="add_category" class="btn">
   </form>

</section>

<!-- product CRUD section ends -->

<!-- show products  -->

<section class="show-products">

   <div class="box-container">

      <?php
         $select_categories = mysqli_query($conn, "SELECT * FROM `BookCategory`") or die('query failed');
         if(mysqli_num_rows($select_categories) > 0){
            while($fetch_categories = mysqli_fetch_assoc($select_categories)){
      ?>
      <div class="box">
         <div class="name"><?php echo $fetch_categories['CategoryCode']; ?></div>
         <div class="name"><?php echo $fetch_categories['CategoryName']; ?></div>
         <a href="admin_categories.php?update=<?php echo $fetch_categories['CategoryCode']; ?>" class="option-btn">Edit</a>
         <a href="admin_categories.php?delete=<?php echo $fetch_categories['CategoryCode']; ?>" class="delete-btn" onclick="return confirm('Delete this category?');">Delete</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty"> There are no categories!</p>';
      }
      ?>
   </div>

</section>


<section class="edit-product-form">

   <?php
      if(isset($_GET['update'])){
         $update_id = $_GET['update'];
         $update_query = mysqli_query($conn, "SELECT * FROM `BookCategory` WHERE CategoryCode = '$update_id'") or die('query failed');
         if(mysqli_num_rows($update_query) > 0){
            while($fetch_update = mysqli_fetch_assoc($update_query)){
   ?>
   <form action="" method="post" enctype="multipart/form-data">
      <input type="hidden" name="update_categorycode" value="<?php echo $fetch_update['CategoryCode']; ?>">
      <input type="text" name="update_categoryname" value="<?php echo $fetch_update['CategoryName']; ?>" class="box" required placeholder="enter product name">
      <input type="submit" value="update" name="update_category" class="btn">
      <input type="reset" value="cancel" id="close-update" class="option-btn">
   </form>
   <?php
         }
      }
      }else{
         echo '<script>document.querySelector(".edit-product-form").style.display = "none";</script>';
      }
   ?>

</section>







<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>
