<?php

include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};

if(isset($_POST['add_author'])){

   $FirstName = mysqli_real_escape_string($conn, $_POST['FirstName']);
   $LastName = mysqli_real_escape_string($conn, $_POST['LastName']);
   $Gender = mysqli_real_escape_string($conn, $_POST['Gender']);
   $DOB = mysqli_real_escape_string($conn, $_POST['DOB']);

   $select_author_name = mysqli_query($conn, "SELECT FirstName, LastName, DOB, Gender FROM `Author` WHERE FirstName= '$FirstName' AND LastName= '$LastName' AND DOB= '$DOB' AND Gender= '$Gender'") or die('query failed');

   if(mysqli_num_rows($select_author_name) > 0){
      $message[] = 'Author Already Exists!';
   }else{
      $add_author_query = mysqli_query($conn, "INSERT INTO `Author`(FirstName, LastName, Gender, DOB) VALUES('$FirstName', '$LastName', '$Gender', '$DOB')") or die('query failed');

      if($add_author_query){
         $message[] = 'Author added successfully!';
      }else{
         $message[] = 'Author failed to be added!';
      }
   }
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM `Author` WHERE AuthorID = '$delete_id'") or die('query failed');
   header('location:admin_authors.php');
}

if(isset($_POST['update_author'])){

   $update_authorid = $_POST['update_authorid'];
   $update_firstname = $_POST['update_firstname'];
   $update_lastname = $_POST['update_lastname'];
   $update_gender = $_POST['update_gender'];
   $update_dob = $_POST['update_dob'];

   mysqli_query($conn, "UPDATE `Author` SET FirstName = '$update_firstname' , LastName = '$update_lastname' , Gender = '$update_gender' , DOB = '$update_dob' WHERE AuthorID = '$update_authorid'" ) or die('query failed');

   header('location:admin_authors.php');

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Authors</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php include 'admin_header.php'; ?>

<!-- product CRUD section starts  -->

<section class="add-products">

   

   <form action="" method="post" enctype="multipart/form-data">
      <input type="text" name="FirstName" class="box" placeholder="First Name" required>
      <input type="text" name="LastName" class="box" placeholder="Last Name" required>
      <input type="date" name="DOB" class="box" required>
      <select name="Gender" class="box">
         <option value="Male">Male</option>
         <option value="Female">Female</option>
      </select>
      <input type="submit" value="Add" name="add_author" class="btn">
   </form>

</section>

<!-- product CRUD section ends -->

<!-- show products  -->

<section class="show-products">

   <div class="box-container">

      <?php
         $select_categories = mysqli_query($conn, "SELECT * FROM `Author`") or die('query failed');
         if(mysqli_num_rows($select_categories) > 0){
            while($fetch_authors = mysqli_fetch_assoc($select_categories)){
      ?>
      <div class="box">
         <div class="name"><?php echo $fetch_authors['FirstName']; ?></div>
         <div class="name"><?php echo $fetch_authors['LastName']; ?></div>
         <div class="name"><?php echo $fetch_authors['DOB']; ?></div>
         <div class="name"><?php echo $fetch_authors['Gender']; ?></div>
         <a href="admin_authors.php?update=<?php echo $fetch_authors['AuthorID']; ?>" class="option-btn">Edit</a>
         <a href="admin_authors.php?delete=<?php echo $fetch_authors['AuthorID']; ?>" class="delete-btn" onclick="return confirm('Delete this category?');">Delete</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty"> There are no authors!</p>';
      }
      ?>
   </div>

</section>

<section class="edit-product-form">

   <?php
      if(isset($_GET['update'])){
         $update_id = $_GET['update'];
         $update_query = mysqli_query($conn, "SELECT * FROM `Author` WHERE AuthorID = '$update_id'") or die('query failed');
         if(mysqli_num_rows($update_query) > 0){
            while($fetch_update = mysqli_fetch_assoc($update_query)){
   ?>
   <form action="" method="post" enctype="multipart/form-data">
      <input type="hidden" name="update_authorid" value="<?php echo $fetch_update['AuthorID']; ?>">
      <input type="text" name="update_firstname" value="<?php echo $fetch_update['FirstName']; ?>" class="box" required placeholder="First Name">
      <input type="text" name="update_lastname" value="<?php echo $fetch_update['LastName']; ?>" class="box" required placeholder="Last Name">
      <input type="date" name="update_dob" value="<?php echo $fetch_update['DOB']; ?>" class="box" required>
      <select name="update_gender" class="box">
         <option value="Male">Male</option>
         <option value="Female">Female</option>
      </select>
      <input type="submit" value="update" name="update_author" class="btn">
      <input type="reset" value="cancel" id="close-update" class="option-btn">
   </form>
   <?php
         }
      }
      }else{
         echo '<script>document.querySelector(".edit-product-form").style.display = "none";</script>';
      }
   ?>

</section>







<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>
