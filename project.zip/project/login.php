<?php

include 'config.php';
session_start();

if(isset($_POST['submit'])){

   $Email = mysqli_real_escape_string($conn, $_POST['Email']);
   $Password = mysqli_real_escape_string($conn, md5($_POST['Password']));

   $select_users = mysqli_query($conn, "SELECT * FROM `Customers` WHERE Email = '$Email' AND Password = '$Password'") or die('query failed');

   if(mysqli_num_rows($select_users) > 0){

      $row = mysqli_fetch_assoc($select_users);

      if($row['User_Type'] == 'admin'){

         $_SESSION['admin_name'] = $row['FirstName'];
         $_SESSION['admin_email'] = $row['Email'];
         $_SESSION['admin_id'] = $row['CustomerID'];
         header('location:admin_page.php');

      }elseif($row['User_Type'] == 'user'){

         $_SESSION['user_name'] = $row['FirstName'];
         $_SESSION['user_email'] = $row['Email'];
         $_SESSION['user_id'] = $row['CustomerID'];
         header('location:home.php');

      }

   }else{
      $message[] = 'Try Again!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>
   
<div class="form-container">

   <form action="" method="post">
      <h3>Not Amazon</h3>
      <input type="email" name="Email" placeholder="Email" required class="box">
      <input type="password" name="Password" placeholder="Password" required class="box">
      <input type="submit" name="submit" value="login" class="btn">
      <p>Don't have an account? <a href="register.php">Register</a></p>
   </form>

</div>

</body>
</html>
