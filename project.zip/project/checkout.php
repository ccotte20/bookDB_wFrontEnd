<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];


if(!isset($user_id)){
   header('location:login.php');
}

$CustomerContactID = $_POST['CustomerContactID'];

if(isset($_POST['order_btn'])){

    mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
        $charid = strtoupper(md5(uniqid(rand(), true)));
        $guid =substr($charid,  0, 8);
         

   $placed_on = date('d-M-Y');

   $cart_total = 0;
   $cart_products[] = '';

   $cart_query = mysqli_query($conn, "SELECT * FROM `Cart` WHERE CustomerID = '$user_id'") or die('query failed');
   if(mysqli_num_rows($cart_query) > 0){
      while($cart_item = mysqli_fetch_assoc($cart_query)){
         $cart_products[] = $cart_item['BookTitle'].' ('.$cart_item['Quantity'].') ';
         $sub_total = ($cart_item['Price'] * $cart_item['Quantity']);
         $cart_total += $sub_total;
      }
   }

   $total_products = implode(', ',$cart_products);

   $sql = "INSERT INTO `Orders`(Order_ID, OrderValue, OrderDetails, CustomerID, Placed_On, Items) VALUES('$guid', '$cart_total', '$CustomerContactID', '$user_id', '$placed_on', '$total_products')";
   
   mysqli_query($conn, "DELETE FROM `Cart` WHERE CustomerID = '$user_id'") or die('query failed');
         
    if(mysqli_query($conn, $sql)){
        $message[] = 'Purchased successfully!';
 
        } else{
            $message[] = 'Order failed, please try again!';
        }

   
   


   
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Checkout</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>


<section class="display-order">

   <?php  
      $grand_total = 0;
      $select_cart = mysqli_query($conn, "SELECT * FROM `Cart` WHERE CustomerID = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select_cart) > 0){
         while($fetch_cart = mysqli_fetch_assoc($select_cart)){
            $total_price = ($fetch_cart['Price'] * $fetch_cart['Quantity']);
            $grand_total += $total_price;
            $Image = $fetch_cart['Image'];
   ?>
   <p> <?php echo 'Item: ' . $fetch_cart['BookTitle']; ?> <br/> 
   (<?php echo 'Qty: ' .$fetch_cart['Quantity']; ?>)<br/> 
   <span> (<?php echo 'Price: $'.$fetch_cart['Price']; ?>)</span>
   <img class="imagesmall" src="<?php echo $fetch_cart['Image']; ?>" alt=""> </p>
   
   
   
   <?php
      }
   }else{
      echo '<p class="empty">your Cart is empty</p>';
   }
   ?>
   <div class="grand-total"> Grand Total : <span>$<?php echo $grand_total; ?></span> </div>

</section>

<div class="TF">
<p>Choose an address!</p>


    <form action="" method="post">
      <select name="CustomerContactID">

<?php

    $select_categories = mysqli_query($conn, "SELECT CustomerContactID, FirstName, LastName, Phone, Street, City, State, ZIP  FROM CustomerContactDetails WHERE CustomerID ='$user_id'") or die('query failed');
    if(mysqli_num_rows($select_categories) > 0){
        while($fetch_categories = mysqli_fetch_assoc($select_categories)){
  ?> 


<option value="<?php echo $fetch_categories['CustomerContactID']; ?>"><?php echo $fetch_categories['FirstName']; ?> <?php echo $fetch_categories['LastName']; ?>,
    <?php echo $fetch_categories['Phone']; ?>, <?php echo $fetch_categories['Street']; ?>,
    <?php echo $fetch_categories['City']; ?> <?php echo $fetch_categories['State']; ?> <?php echo $fetch_categories['ZIP']; ?>
</option>

         <?php
         }
      }else{
         echo '<p class="empty"> There are no categories!</p>';
      }
      ?>
  

</select>
      <input type="submit" value="Submit Order" class="btn" name="order_btn">
   </form>
   </div>
<?php include 'footer.php'; ?>





<!-- custom js file link  -->
<script src="js/script.js"></script>



</body>
</html>