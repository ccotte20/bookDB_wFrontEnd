<?php

include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};

if(isset($_POST['add_user'])){

   $FirstName = mysqli_real_escape_string($conn, $_POST['FirstName']);
   $LastName = mysqli_real_escape_string($conn, $_POST['LastName']);
   $Email = mysqli_real_escape_string($conn, $_POST['Email']);
   $Password = mysqli_real_escape_string($conn, md5($_POST['Password']));
   $cpass = mysqli_real_escape_string($conn, md5($_POST['cpassword']));
   $User_Type = $_POST['User_Type'];

   $select_users = mysqli_query($conn, "SELECT * FROM `Customers` WHERE Email = '$Email' AND Password = '$Password'") or die('query failed');

   if(mysqli_num_rows($select_users) > 0){
      $message[] = 'User Exists, Please Login!';
   }else{
      if($Password != $cpass){
         $message[] = 'Passwords do not match!!';
      }else{
         mysqli_query($conn, "INSERT INTO `Customers`(FirstName, LastName, Email, Password, User_Type) VALUES('$FirstName', '$LastName', '$Email', '$cpass','$User_Type')") or die('query failed');
         $message[] = 'Registered successfully!';
         header('location:admin_users.php');
      }
   }

}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM `Customers` WHERE CustomerID = '$delete_id'") or die('query failed');
   header('location:admin_users.php');
}

if(isset($_POST['update_user'])){

   $update_customerid = $_POST['update_customerid'];
   $update_firstname = $_POST['update_firstname'];
   $update_lastname = $_POST['update_lastname'];
   $update_usertype = $_POST['update_usertype'];
   $update_email = $_POST['update_email'];
   $update_password = mysqli_real_escape_string($conn, md5($_POST['update_password']));
   $update_cpass = mysqli_real_escape_string($conn, md5($_POST['update_cpassword']));
 
  $update_users = mysqli_query($conn, "SELECT * FROM `Customers` WHERE Email = '$update_email' AND Password = '$update_cpass'") or die('query failed');

   if(mysqli_num_rows($update_users) > 0){
      $message[] = 'User Exists, Please Login!';
   }else{
      if($update_password != $update_cpass){
         $message[] = 'Passwords do not match!!';
      }else{
         mysqli_query($conn, "UPDATE `Customers` SET FirstName = '$update_firstname' , LastName = '$update_lastname' , Email = '$update_email' , Password = '$update_cpass', User_Type ='$update_usertype' WHERE CustomerID = '$update_customerid'" ) or die('query failed');
         $message[] = 'Registered successfully!';
         header('location:admin_users.php');
      }
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Users</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php include 'admin_header.php'; ?>

<!-- product CRUD section starts  -->

<section class="add-products">


   <form action="" method="post" enctype="multipart/form-data">
      <input type="text" name="FirstName" placeholder="First Name" required class="box">
      <input type="text" name="LastName" placeholder="Last Name" required class="box">
      <input type="email" name="Email" placeholder="Email Address" required class="box">
      <input type="password" name="Password" placeholder="Password" required class="box">
      <input type="password" name="cpassword" placeholder="Confirm Password" required class="box">
      <select name="User_Type" class="box">
         <option value="user">Regular User</option>
         <option value="admin">Admin User</option>
      </select>
      <input type="submit" value="Add" name="add_user" class="btn">
   </form>

</section>

<!-- product CRUD section ends -->

<!-- show products  -->

<section class="show-products">

   <div class="box-container">

      <?php
         $select_categories = mysqli_query($conn, "SELECT * FROM `Customers`") or die('query failed');
         if(mysqli_num_rows($select_categories) > 0){
            while($fetch_authors = mysqli_fetch_assoc($select_categories)){
      ?>
      <div class="box">
         <div class="name"><?php echo $fetch_authors['FirstName']; ?></div>
         <div class="name"><?php echo $fetch_authors['LastName']; ?></div>
         <div class="name"><?php echo $fetch_authors['Email']; ?></div>
         <div class="name"><?php echo $fetch_authors['User_Type']; ?></div>
         <a href="admin_users.php?update=<?php echo $fetch_authors['CustomerID']; ?>" class="option-btn">Edit</a>
         <a href="admin_users.php?delete=<?php echo $fetch_authors['CustomerID']; ?>" class="delete-btn" onclick="return confirm('Delete this category?');">Delete</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty"> There are no authors!</p>';
      }
      ?>
   </div>

</section>

<section class="edit-product-form">

   <?php
      if(isset($_GET['update'])){
         $update_id = $_GET['update'];
         $update_query = mysqli_query($conn, "SELECT * FROM `Customers` WHERE CustomerID = '$update_id'") or die('query failed');
         if(mysqli_num_rows($update_query) > 0){
            while($fetch_update = mysqli_fetch_assoc($update_query)){
   ?>
   <form action="" method="post" enctype="multipart/form-data">
      <input type="hidden" name="update_customerid" value="<?php echo $fetch_update['CustomerID']; ?>">
      <input type="text" name="update_firstname" value="<?php echo $fetch_update['FirstName']; ?>" class="box" required placeholder="First Name">
      <input type="text" name="update_lastname" value="<?php echo $fetch_update['LastName']; ?>" class="box" required placeholder="Last Name">
      <input type="text" name="update_email" value="<?php echo $fetch_update['Email']; ?>" class="box" required>
      <input type="password" name="update_password" value="<?php echo $fetch_update['Password']; ?>" class="box" required placeholder="Password">
      <input type="password" name="update_cpassword" placeholder="Confirm Password" required class="box">
      <select name="update_usertype" class="box">
         <option value="user">Regular User</option>
         <option value="admin">Admin User</option>
      </select>
      <input type="submit" value="update" name="update_user" class="btn">
      <input type="reset" value="cancel" id="close-update" class="option-btn">
   </form>
   <?php
         }
      }
      }else{
         echo '<script>document.querySelector(".edit-product-form").style.display = "none";</script>';
      }
   ?>

</section>







<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>
