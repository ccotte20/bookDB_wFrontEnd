-- MariaDB dump 10.19  Distrib 10.6.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	10.6.11-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Author`
--

DROP TABLE IF EXISTS `Author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Author` (
  `AuthorID` int(100) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  PRIMARY KEY (`AuthorID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Author`
--

LOCK TABLES `Author` WRITE;
/*!40000 ALTER TABLE `Author` DISABLE KEYS */;
INSERT INTO `Author` VALUES (8,'Ian ','McEwan','Male','1948-01-20'),(9,'Barbara','Kingsolver','Female','1955-07-20'),(10,'Jennifer','Egan','Female','1962-05-08'),(11,'J.K','Rowling','Female','1965-07-12');
/*!40000 ALTER TABLE `Author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BookCategory`
--

DROP TABLE IF EXISTS `BookCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BookCategory` (
  `CategoryCode` int(4) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(100) NOT NULL,
  PRIMARY KEY (`CategoryCode`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BookCategory`
--

LOCK TABLES `BookCategory` WRITE;
/*!40000 ALTER TABLE `BookCategory` DISABLE KEYS */;
INSERT INTO `BookCategory` VALUES (27,'Horror'),(68,'Thriller'),(69,'History'),(70,'Teens'),(71,'Self Help'),(72,'Spanish');
/*!40000 ALTER TABLE `BookCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Books`
--

DROP TABLE IF EXISTS `Books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Books` (
  `ISBN` varchar(100) NOT NULL,
  `Title` varchar(45) NOT NULL,
  `PublicationDate` date NOT NULL,
  `Price` decimal(10,0) NOT NULL,
  `Image` varchar(100) NOT NULL,
  PRIMARY KEY (`ISBN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Books`
--

LOCK TABLES `Books` WRITE;
/*!40000 ALTER TABLE `Books` DISABLE KEYS */;
INSERT INTO `Books` VALUES ('1476716765','The Candy House: A Novel','2022-12-14',20,'https://pictures.abebooks.com/isbn/9781476716763-us.jpg'),('1787333981','Lessons','2022-12-14',16,'https://pictures.abebooks.com/isbn/9781787333987-us.jpg'),('63251922','Demon Copperhead: A Novel','2022-12-13',26,'https://pictures.abebooks.com/isbn/9780063251922-us.jpg');
/*!40000 ALTER TABLE `Books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cart`
--

DROP TABLE IF EXISTS `Cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cart` (
  `CartID` int(100) NOT NULL AUTO_INCREMENT,
  `CustomerID` int(100) NOT NULL,
  `BookTitle` varchar(100) NOT NULL,
  `Price` int(100) NOT NULL,
  `Quantity` int(100) NOT NULL,
  `Image` varchar(100) NOT NULL,
  `ISBN` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CartID`),
  KEY `CustomerID` (`CustomerID`),
  CONSTRAINT `CustomerID` FOREIGN KEY (`CustomerID`) REFERENCES `Customers` (`CustomerID`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cart`
--

LOCK TABLES `Cart` WRITE;
/*!40000 ALTER TABLE `Cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `Cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CustomerContactDetails`
--

DROP TABLE IF EXISTS `CustomerContactDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CustomerContactDetails` (
  `CustomerContactID` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(45) NOT NULL,
  `LastName` varchar(45) NOT NULL,
  `Phone` varchar(10) NOT NULL,
  `Street` varchar(100) NOT NULL,
  `City` varchar(45) NOT NULL,
  `State` varchar(45) NOT NULL,
  `ZIP` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  PRIMARY KEY (`CustomerContactID`),
  KEY `CustomerID_idx` (`CustomerID`),
  CONSTRAINT `CustomerID_ContactDetails` FOREIGN KEY (`CustomerID`) REFERENCES `Customers` (`CustomerID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CustomerContactDetails`
--

LOCK TABLES `CustomerContactDetails` WRITE;
/*!40000 ALTER TABLE `CustomerContactDetails` DISABLE KEYS */;
INSERT INTO `CustomerContactDetails` VALUES (4,'Manuel','Morfin','2222222222','The Hiuse','Houston','Texas',23123,13),(5,'Manuel','Morfin','2815548485','The Street Lives','Gotham','TX',78943,14);
/*!40000 ALTER TABLE `CustomerContactDetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customers`
--

DROP TABLE IF EXISTS `Customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customers` (
  `CustomerID` int(100) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `User_Type` varchar(20) NOT NULL DEFAULT 'user',
  PRIMARY KEY (`CustomerID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customers`
--

LOCK TABLES `Customers` WRITE;
/*!40000 ALTER TABLE `Customers` DISABLE KEYS */;
INSERT INTO `Customers` VALUES (1,'Admin','Admin','admin@admin.com','5f4dcc3b5aa765d61d8327deb882cf99','admin'),(13,'user','user','user@user.com','5f4dcc3b5aa765d61d8327deb882cf99','user'),(14,'Manuel','Morfin','m@m.com','0cc175b9c0f1b6a831c399e269772661','user'),(15,'Tony','Smith','Tony@smith.com','ad0234829205b9033196ba818f7a872b','admin');
/*!40000 ALTER TABLE `Customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Orders` (
  `Order_ID` varchar(100) NOT NULL,
  `OrderValue` decimal(19,4) NOT NULL,
  `OrderDetails` int(11) NOT NULL,
  `Placed_On` varchar(100) NOT NULL,
  `Items` varchar(500) NOT NULL,
  `CustomerID` int(100) NOT NULL,
  PRIMARY KEY (`Order_ID`),
  KEY `CustomerID_idx` (`CustomerID`),
  CONSTRAINT `CustomerID_Orders` FOREIGN KEY (`CustomerID`) REFERENCES `Customers` (`CustomerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Orders`
--

LOCK TABLES `Orders` WRITE;
/*!40000 ALTER TABLE `Orders` DISABLE KEYS */;
INSERT INTO `Orders` VALUES ('0AF15060',62.0000,5,'01-Dec-2022',', The Candy House: A Novel (1) , Demon Copperhead: A Novel (1) , Lessons (1) ',14),('110A8058',26.0000,5,'01-Dec-2022',', Demon Copperhead: A Novel (1) ',14),('2C9C3A6D',26.0000,6,'01-Dec-2022',', Demon Copperhead: A Novel (1) ',13),('3538F673',36.0000,6,'01-Dec-2022',', The Candy House: A Novel (1) , Lessons (1) ',13),('424E5549',40.0000,4,'01-Dec-2022',', Test Book (1) , The Candy House: A Novel (1) ',13),('4A204435',136.0000,5,'01-Dec-2022',', Lessons (2) , Demon Copperhead: A Novel (4) ',14),('6241D70B',62.0000,5,'01-Dec-2022',', Demon Copperhead: A Novel (1) , The Candy House: A Novel (1) , Lessons (1) ',14),('6CD0C288',16.0000,4,'01-Dec-2022',', Lessons (1) ',13),('7FF6C0BB',62.0000,6,'01-Dec-2022',', The Candy House: A Novel (1) , Lessons (1) , Demon Copperhead: A Novel (1) ',13),('A4EF0F6A',16.0000,4,'01-Dec-2022',', Lessons (1) ',13),('B6E5DFFD',16.0000,5,'01-Dec-2022',', Lessons (1) ',14),('B96FC0EE',0.0000,5,'01-Dec-2022','',14),('BB087305',26.0000,5,'01-Dec-2022',', Demon Copperhead: A Novel (1) ',14),('D731E363',62.0000,4,'01-Dec-2022',', The Candy House: A Novel (1) , Lessons (1) , Demon Copperhead: A Novel (1) ',13),('DB81743F',62.0000,5,'01-Dec-2022',', The Candy House: A Novel (1) , Lessons (1) , Demon Copperhead: A Novel (1) ',14),('FDE4508E',16.0000,5,'01-Dec-2022',', Lessons (1) ',14);
/*!40000 ALTER TABLE `Orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Supplier`
--

DROP TABLE IF EXISTS `Supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Supplier` (
  `SupplierID` int(11) NOT NULL AUTO_INCREMENT,
  `SupplierName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`SupplierID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Supplier`
--

LOCK TABLES `Supplier` WRITE;
/*!40000 ALTER TABLE `Supplier` DISABLE KEYS */;
INSERT INTO `Supplier` VALUES (3,'Amazon'),(4,'Barns & Nobles');
/*!40000 ALTER TABLE `Supplier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-01 15:30:27
