Make sure to edit the config.php file to configure the database connection, name, and password

default logins:
username: admin@admin.com
password: password

username: user@user.com
password: password

